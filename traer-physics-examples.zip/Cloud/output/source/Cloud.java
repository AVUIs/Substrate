import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import traer.physics.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cloud extends PApplet {



Particle mouse;
Particle[] others;
ParticleSystem physics;

PImage img;

public void setup()
{
  size( 400, 400 );
  frameRate( 24 );
  cursor( CROSS );
  
  img = loadImage( "fade.png" );
  imageMode( CORNER );
  tint( 0, 32 );
  
  physics = new ParticleSystem( 0, 0.1f );
  mouse = physics.makeParticle();
  mouse.makeFixed();
  
  others = new Particle[1000];
  for ( int i = 0; i < others.length; i++ )
  {
    others[i] = physics.makeParticle( 1.0f, random( 0, width ), random( 0, height ), 0 );
    physics.makeAttraction( mouse, others[i], 5000, 50 ); 
  }
}

public void draw()
{
  mouse.position().set( mouseX, mouseY, 0 );
  
  physics.tick();

  //background( 255 );
  
  for ( int i = 0; i < others.length; i++ )
  {
     Particle p = others[i];
     image( img,p.position().x()-img.width/2,p.position().y()-img.height/2 );
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Cloud" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
